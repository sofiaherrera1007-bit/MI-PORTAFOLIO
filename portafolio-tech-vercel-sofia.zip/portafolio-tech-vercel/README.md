# Portafolio tecnológico — listo para Vercel

Este sitio estático está construido con HTML, CSS y JavaScript. No incluye proyectos ficticios, datos personales inventados, enlaces vacíos ni campos tipo “[escribe aquí]”. El contenido presenta honestamente una etapa de aprendizaje en Python, JavaScript, requisitos de software y lógica de programación.

## Publicar en Vercel
1. Descarga y descomprime el ZIP.
2. Sube `index.html`, `styles.css` y `script.js` a un repositorio de GitHub.
3. Entra en https://vercel.com e inicia sesión con GitHub.
4. Selecciona **Add New → Project** y elige el repositorio.
5. Selecciona el tipo **Other** si pregunta por framework. No necesita build command.
6. Pulsa **Deploy**. Vercel publicará la web y mostrará una dirección para compartir.

## Nota
Como no se proporcionó nombre, correo ni enlaces personales, el portafolio no inventa esos datos. La presentación se mantiene profesional y no contiene espacios para rellenar. Antes de usarlo en una postulación, se recomienda agregar un nombre y un medio de contacto real cuando se tengan.
